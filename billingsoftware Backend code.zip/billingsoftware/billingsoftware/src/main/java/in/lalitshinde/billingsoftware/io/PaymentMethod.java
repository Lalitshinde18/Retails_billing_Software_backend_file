package in.lalitshinde.billingsoftware.io;

public enum PaymentMethod {
    CASH, UPI
}
