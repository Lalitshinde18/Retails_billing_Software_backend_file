package in.lalitshinde.billingsoftware.service;

import in.lalitshinde.billingsoftware.io.CategoryRequest;
import in.lalitshinde.billingsoftware.io.CategoryResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface CategoryService {

    CategoryResponse add(CategoryRequest Request , MultipartFile file);


    List<CategoryResponse> read();

    void delete (String categoryId);
}
