

package in.lalitshinde.billingsoftware.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${file.upload-dir}")
    private String uploadDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Convert relative upload directory path to an absolute path
        Path uploadPath = Paths.get(uploadDir).toAbsolutePath();


        String resourceLocation = "file:///" + uploadPath.toString().replace("\\", "/") + "/";

        System.out.println("🟢 Mapping /uploads/** to: " + resourceLocation);

        // ✅ Registering a virtual path (/uploads/**) that maps to the physical folder
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(resourceLocation);
    }
}


